// ----------------------------------------------------------------------------
// myTimers.c  (for lab_06b_upTimer project) ('F5529 Launchpad)
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <driverlib/MSP430F5xx_6xx/driverlib.h>
#include "myTimers.h"

//*****************************************************************************
// Initialize Timer
//*****************************************************************************
void initTimers(void)
{

    //Timer_A_initContinuousModeParam initContParam = { 0 };
    Timer_A_initUpModeParam initUpParam = { 0 };

        initUpParam.clockSource =                 TIMER_A_CLOCKSOURCE_ACLK;       //
        initUpParam.clockSourceDivider =          TIMER_A_CLOCKSOURCE_DIVIDER_1;  //

        initUpParam.timerPeriod = 0xFFFF / 2;                                       //

        initUpParam.timerInterruptEnable_TAIE =   TIMER_A_TAIE_INTERRUPT_ENABLE;  //

        initUpParam.captureCompareInterruptEnable_CCR0_CCIE = TIMER_A_CCIE_CCR0_INTERRUPT_ENABLE;

        initUpParam.timerClear =                  TIMER_A_DO_CLEAR;               //
        initUpParam.startTimer =                  false;                          //

    //Timer_A_initContinuousMode( TIMER_A0_BASE, &initContParam );
    Timer_A_initUpMode( TIMER_A0_BASE, &initUpParam );


    //Clear the timer interrupt flag
    //Timer_A_clearTimerInterruptFlag( TIMER_A0_BASE ); //Clear TAOIFG

    Timer_A_clearCaptureCompareInterrupt(
            TIMER_A0_BASE,
            TIMER_A_CAPTURECOMPARE_REGISTER_0);



    Timer_A_startCounter(           //Function to start timer
        TIMER_A0_BASE,              //Timer A0
        TIMER_A_UP_MODE     //Run in Continuous mode
    );
}


#pragma vector=TIMER0_A0_VECTOR

__interrupt void timer0_ISR (void)
{

        //Toggle the LED on/off

         GPIO_toggleOutputOnPin(GPIO_PORT_P1, GPIO_PIN0);


}
