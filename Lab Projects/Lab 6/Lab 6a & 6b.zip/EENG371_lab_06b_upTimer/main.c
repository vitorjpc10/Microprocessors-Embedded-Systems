#include <msp430.h> 
#include <driverlib/MSP430F5xx_6xx/driverlib.h>
#include "myClocks.h"
#include "myTimers.h"
#include "myGpio.h"

//****************** Prototypes *******************
void initGPIO(void);


/**
 * main.c
 */

//************** Defines **********************
#define ONE_SECOND 800000
#define HALF_SECOND 400000


//************** Functions **********************
void main(void)
{
    //WDTCTL = WDTPW | WDTHOLD; // stop watchdog timer
    WDT_A_hold( WDT_A_BASE ); // stop watchdog timer

    //Initialize GPIO
    initGPIO();

    //Initialize the Timer
    initTimers();

    //Initialize Clocks
    initClocks();


    //Enables interrupts globally
    __bis_SR_register( GIE );


    while(1)
    {

        //        //P1OUT ^= 0x01; toggle P1.0 and Turn ON LED
        //        GPIO_setOutputHighOnPin(GPIO_PORT_P1, GPIO_PIN0); //sets P1.0 to high
        //
        //        //Wait
        //        _delay_cycles( ONE_SECOND ); // Sets a delay time for one second
        //
        //        //P1OUT ^= 0x01; //toggles P1.0 and Turn OFF LED
        //        GPIO_setOutputLowOnPin(GPIO_PORT_P1, GPIO_PIN0);  //sets P1.0 to low
        //
        //        //Wait
        //        _delay_cycles( ONE_SECOND ); // Sets a delay time for one second
    }

}
