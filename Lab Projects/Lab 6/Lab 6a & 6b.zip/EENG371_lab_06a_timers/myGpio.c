// ----------------------------------------------------------------------------
// myGpio.c ('F5529 Launchpad)
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <driverlib/MSP430F5xx_6xx/driverlib.h>                                                         // DriverLib include file
#include <myGpio.h>

//*****************************************************************************
// Initialize GPIO
//*****************************************************************************
void initGPIO(void) {

    GPIO_setAsOutputPin( GPIO_PORT_P1, GPIO_PIN0 );                             // Red LED (LED1)
    GPIO_setOutputLowOnPin( GPIO_PORT_P1, GPIO_PIN0 );


    GPIO_setAsOutputPin( GPIO_PORT_P4, GPIO_PIN7 );                             // Green LED (LED2)
    GPIO_setOutputLowOnPin( GPIO_PORT_P4, GPIO_PIN7 );

}

