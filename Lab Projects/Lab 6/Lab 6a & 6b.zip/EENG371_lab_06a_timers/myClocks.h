/*
 * myClocks.h
 *
 *  Created on: Apr 6, 2020
 *      Author: vitor
 */

#ifndef MYCLOCKS_H_
#define MYCLOCKS_H_

//*************** Prototypes ************************************************
void initClocks(void);




#endif /* MYCLOCKS_H_ */
