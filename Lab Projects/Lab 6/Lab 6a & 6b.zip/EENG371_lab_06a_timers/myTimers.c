// ----------------------------------------------------------------------------
// myTimers.c  (for lab_06a_timer project) ('F5529 Launchpad)
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <driverlib/MSP430F5xx_6xx/driverlib.h>
#include "myTimers.h"
#include "myGpio.h"
#include "myClocks.h"

//*****************************************************************************
// Initialize Timer
//*****************************************************************************
void initTimers(void)
{

    Timer_A_initContinuousModeParam initContParam = { 0 };
    initContParam.clockSource =                 TIMER_A_CLOCKSOURCE_ACLK;       //
    initContParam.clockSourceDivider =          TIMER_A_CLOCKSOURCE_DIVIDER_1;  //
    initContParam.timerInterruptEnable_TAIE =   TIMER_A_TAIE_INTERRUPT_ENABLE;  //
    initContParam.timerClear =                  TIMER_A_DO_CLEAR;               //
    initContParam.startTimer =                  false;                          //
    Timer_A_initContinuousMode( TIMER_A0_BASE, &initContParam );

    //Clear the timer interrupt flag
    //Timer_A_clearTimerInterruptFlag( TIMER_A0_BASE ); //Clear TAOIFG


    //start Timer
    Timer_A_startCounter(               //Function to start timer
            TIMER_A0_BASE,              //Timer A0
            TIMER_A_CONTINUOUS_MODE     //Run in Continuous mode
    );
}


#pragma vector=TIMER0_A1_VECTOR

__interrupt void timer0_ISR (void)
{
    switch( __even_in_range( TA0IV, 14 )) {
    case TA0IV_NONE: break;                 // (0x00) None
    case TA0IV_TACCR1:                      // (0x02) CCR1 IFG
        _no_operation();
        break;
    case TA0IV_TACCR2:                      // (0x04) CCR2 IFG
        _no_operation();
        break;
    case TA0IV_TACCR3:                      // (0x06) CCR3 IFG
        _no_operation();
        break;
    case TA0IV_TACCR4:                      // (0x08) CCR4 IFG
        _no_operation();
        break;
    case TA0IV_5: break;                    // (0x0A) Reserved
    case TA0IV_6: break;                    // (0x0C) Reserved
    case TA0IV_TAIFG:                       // (0x0E) TA0IFG - TAR overflow

        GPIO_toggleOutputOnPin(GPIO_PORT_P4, GPIO_PIN7);

        break;
    default: _never_executed();
    }
}
